package com.tcs.employeeservice.employee.audit;

import jakarta.persistence.*;
import org.hibernate.envers.DefaultRevisionEntity;
import org.hibernate.envers.RevisionEntity;

@Entity
@Table(name = "custom_revinfo")
@RevisionEntity(CustomRevisionListener.class)
public class CustomRevisionEntity extends DefaultRevisionEntity {
    
    @Column(name = "username", length = 100)
    private String username;
    
    @Column(name = "user_role", length = 50)
    private String userRole;
    
    @Column(name = "ip_address", length = 45)
    private String ipAddress;
    
    @Column(name = "operation_type", length = 20)
    private String operationType;
    
    // Constructors
    public CustomRevisionEntity() {}
    
    // Getters and Setters
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    
    public String getUserRole() { return userRole; }
    public void setUserRole(String userRole) { this.userRole = userRole; }
    
    public String getIpAddress() { return ipAddress; }
    public void setIpAddress(String ipAddress) { this.ipAddress = ipAddress; }
    
    public String getOperationType() { return operationType; }
    public void setOperationType(String operationType) { this.operationType = operationType; }
}
