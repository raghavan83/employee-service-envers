package com.tcs.employeeservice.employee.audit;

import jakarta.servlet.http.HttpServletRequest;
import org.hibernate.envers.RevisionListener;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

public class CustomRevisionListener implements RevisionListener {
    
    @Override
    public void newRevision(Object revisionEntity) {
        CustomRevisionEntity customRevisionEntity = (CustomRevisionEntity) revisionEntity;
        
        try {
            ServletRequestAttributes requestAttributes = 
                (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
            HttpServletRequest request = requestAttributes.getRequest();
            
            // Extract user information from security context or request headers
            String username = extractUsername(request);
            String userRole = extractUserRole(request);
            String ipAddress = getClientIpAddress(request);
            String operationType = request.getMethod();
            
            customRevisionEntity.setUsername(username);
            customRevisionEntity.setUserRole(userRole);
            customRevisionEntity.setIpAddress(ipAddress);
            customRevisionEntity.setOperationType(operationType);
            
        } catch (Exception e) {
            // Fallback values
            customRevisionEntity.setUsername("system");
            customRevisionEntity.setUserRole("SYSTEM");
            customRevisionEntity.setIpAddress("unknown");
            customRevisionEntity.setOperationType("UNKNOWN");
        }
    }
    
    private String extractUsername(HttpServletRequest request) {
        // Extract from security context or custom header
        String username = request.getHeader("X-User-Name");
        return username != null ? username : "anonymous";
    }
    
    private String extractUserRole(HttpServletRequest request) {
        // Extract from security context or custom header
        String role = request.getHeader("X-User-Role");
        return role != null ? role : "USER";
    }
    
    private String getClientIpAddress(HttpServletRequest request) {
        String xForwardedFor = request.getHeader("X-Forwarded-For");
        if (xForwardedFor != null && !xForwardedFor.isEmpty()) {
            return xForwardedFor.split(",")[0].trim();
        }
        
        String xRealIP = request.getHeader("X-Real-IP");
        if (xRealIP != null && !xRealIP.isEmpty()) {
            return xRealIP;
        }
        
        return request.getRemoteAddr();
    }
}
