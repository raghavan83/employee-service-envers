package com.tcs.employeeservice.employee.controller;

// TODO: Update these imports to match your actual package structure.
// For example, if your DTO, entity, and service classes are under com.tcs.employeeservice.employee.*
import com.tcs.employeeservice.employee.dto.EmployeeDTO;
import com.tcs.employeeservice.employee.entity.Employee;
import com.tcs.employeeservice.employee.entity.EmployeeStatus;
import com.tcs.employeeservice.employee.service.EmployeeService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.history.Revision;
import org.springframework.data.history.Revisions;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/employees")
@Tag(name = "Employee Management", description = "CRUD operations for Employee management")
@CrossOrigin(origins = "http://localhost:4200", allowCredentials = "true")
public class EmployeeController {
    
    private final EmployeeService employeeService;
    
    @Autowired
    public EmployeeController(EmployeeService employeeService) {
        this.employeeService = employeeService;
    }
    
    @GetMapping
    @Operation(summary = "Get all employees", description = "Retrieve all employees with optional filtering and pagination")
    @ApiResponse(responseCode = "200", description = "Successfully retrieved employees")
    public ResponseEntity<Page<EmployeeDTO>> getAllEmployees(
            @Parameter(description = "Filter by first name") @RequestParam(required = false) String firstName,
            @Parameter(description = "Filter by last name") @RequestParam(required = false) String lastName,
            @Parameter(description = "Filter by department") @RequestParam(required = false) String department,
            @Parameter(description = "Filter by status") @RequestParam(required = false) EmployeeStatus status,
            @PageableDefault(size = 20, sort = "lastName", direction = Sort.Direction.ASC) Pageable pageable) {
        
        Page<EmployeeDTO> employees = employeeService.getEmployeesWithFilters(
            firstName, lastName, department, status, pageable);
        return ResponseEntity.ok(employees);
    }
    
    @GetMapping("/{id}")
    @Operation(summary = "Get employee by ID", description = "Retrieve a specific employee by their ID")
    @ApiResponse(responseCode = "200", description = "Successfully retrieved employee")
    @ApiResponse(responseCode = "404", description = "Employee not found")
    public ResponseEntity<EmployeeDTO> getEmployeeById(
            @Parameter(description = "Employee ID") @PathVariable Long id) {
        EmployeeDTO employee = employeeService.getEmployeeById(id);
        return ResponseEntity.ok(employee);
    }
    
    @GetMapping("/by-employee-number/{employeeNumber}")
    @Operation(summary = "Get employee by employee number", 
               description = "Retrieve a specific employee by their employee number")
    @ApiResponse(responseCode = "200", description = "Successfully retrieved employee")
    @ApiResponse(responseCode = "404", description = "Employee not found")
    public ResponseEntity<EmployeeDTO> getEmployeeByEmployeeNumber(
            @Parameter(description = "Employee Number") @PathVariable String employeeNumber) {
        EmployeeDTO employee = employeeService.getEmployeeByEmployeeNumber(employeeNumber);
        return ResponseEntity.ok(employee);
    }
    
    @PostMapping
    @Operation(summary = "Create new employee", description = "Create a new employee record")
    @ApiResponse(responseCode = "201", description = "Employee successfully created")
    @ApiResponse(responseCode = "400", description = "Invalid input data")
    @ApiResponse(responseCode = "409", description = "Employee already exists")
    public ResponseEntity<EmployeeDTO> createEmployee(
            @Parameter(description = "Employee data") @Valid @RequestBody EmployeeDTO employeeDTO) {
        EmployeeDTO createdEmployee = employeeService.createEmployee(employeeDTO);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdEmployee);
    }
    
    @PutMapping("/{id}")
    @Operation(summary = "Update employee", description = "Update an existing employee record")
    @ApiResponse(responseCode = "200", description = "Employee successfully updated")
    @ApiResponse(responseCode = "400", description = "Invalid input data")
    @ApiResponse(responseCode = "404", description = "Employee not found")
    @ApiResponse(responseCode = "409", description = "Duplicate email address")
    public ResponseEntity<EmployeeDTO> updateEmployee(
            @Parameter(description = "Employee ID") @PathVariable Long id,
            @Parameter(description = "Updated employee data") @Valid @RequestBody EmployeeDTO employeeDTO) {
        EmployeeDTO updatedEmployee = employeeService.updateEmployee(id, employeeDTO);
        return ResponseEntity.ok(updatedEmployee);
    }
    
    @DeleteMapping("/{id}")
    @Operation(summary = "Delete employee", description = "Delete an employee record")
    @ApiResponse(responseCode = "204", description = "Employee successfully deleted")
    @ApiResponse(responseCode = "404", description = "Employee not found")
    @ApiResponse(responseCode = "400", description = "Cannot delete employee with active subordinates")
    public ResponseEntity<Void> deleteEmployee(
            @Parameter(description = "Employee ID") @PathVariable Long id) {
        employeeService.deleteEmployee(id);
        return ResponseEntity.noContent().build();
    }
    
    @PutMapping("/{id}/terminate")
    @Operation(summary = "Terminate employee", description = "Mark employee as terminated")
    @ApiResponse(responseCode = "200", description = "Employee successfully terminated")
    @ApiResponse(responseCode = "404", description = "Employee not found")
    public ResponseEntity<EmployeeDTO> terminateEmployee(
            @Parameter(description = "Employee ID") @PathVariable Long id) {
        EmployeeDTO terminatedEmployee = employeeService.terminateEmployee(id);
        return ResponseEntity.ok(terminatedEmployee);
    }
    
    @PutMapping("/{id}/reactivate")
    @Operation(summary = "Reactivate employee", description = "Reactivate a terminated employee")
    @ApiResponse(responseCode = "200", description = "Employee successfully reactivated")
    @ApiResponse(responseCode = "404", description = "Employee not found")
    public ResponseEntity<EmployeeDTO> reactivateEmployee(
            @Parameter(description = "Employee ID") @PathVariable Long id) {
        EmployeeDTO reactivatedEmployee = employeeService.reactivateEmployee(id);
        return ResponseEntity.ok(reactivatedEmployee);
    }
    
    @GetMapping("/departments")
    @Operation(summary = "Get all departments", description = "Retrieve list of all departments")
    @ApiResponse(responseCode = "200", description = "Successfully retrieved departments")
    public ResponseEntity<List<String>> getAllDepartments() {
        List<String> departments = employeeService.getAllDepartments();
        return ResponseEntity.ok(departments);
    }
    
    @GetMapping("/by-department/{department}")
    @Operation(summary = "Get employees by department", 
               description = "Retrieve all employees in a specific department")
    @ApiResponse(responseCode = "200", description = "Successfully retrieved employees")
    public ResponseEntity<List<EmployeeDTO>> getEmployeesByDepartment(
            @Parameter(description = "Department name") @PathVariable String department) {
        List<EmployeeDTO> employees = employeeService.getEmployeesByDepartment(department);
        return ResponseEntity.ok(employees);
    }
    
    @GetMapping("/{managerId}/subordinates")
    @Operation(summary = "Get subordinates", description = "Retrieve all subordinates of a manager")
    @ApiResponse(responseCode = "200", description = "Successfully retrieved subordinates")
    public ResponseEntity<List<EmployeeDTO>> getSubordinates(
            @Parameter(description = "Manager ID") @PathVariable Long managerId) {
        List<EmployeeDTO> subordinates = employeeService.getSubordinates(managerId);
        return ResponseEntity.ok(subordinates);
    }
    
    // Audit endpoints
    @GetMapping("/{id}/revisions")
    @Operation(summary = "Get employee audit history", 
               description = "Retrieve all audit revisions for an employee")
    @ApiResponse(responseCode = "200", description = "Successfully retrieved audit history")
    @ApiResponse(responseCode = "404", description = "Employee not found")
    public ResponseEntity<Revisions<Long, Employee>> getEmployeeRevisions(
            @Parameter(description = "Employee ID") @PathVariable Long id) {
        Revisions<Long, Employee> revisions = employeeService.getEmployeeRevisions(id);
        return ResponseEntity.ok(revisions);
    }
    
    @GetMapping("/{id}/revisions/{revisionNumber}")
    @Operation(summary = "Get specific employee revision", 
               description = "Retrieve a specific audit revision for an employee")
    @ApiResponse(responseCode = "200", description = "Successfully retrieved revision")
    @ApiResponse(responseCode = "404", description = "Employee or revision not found")
    public ResponseEntity<Revision<Long, Employee>> getEmployeeRevision(
            @Parameter(description = "Employee ID") @PathVariable Long id,
            @Parameter(description = "Revision number") @PathVariable Long revisionNumber) {
        Optional<Revision<Long, Employee>> revision = 
            employeeService.getEmployeeRevision(id, revisionNumber);
        return revision.map(ResponseEntity::ok)
                      .orElse(ResponseEntity.notFound().build());
    }
    
    @GetMapping("/{id}/revisions/last")
    @Operation(summary = "Get last employee revision", 
               description = "Retrieve the most recent audit revision for an employee")
    @ApiResponse(responseCode = "200", description = "Successfully retrieved last revision")
    @ApiResponse(responseCode = "404", description = "Employee not found")
    public ResponseEntity<Revision<Long, Employee>> getLastEmployeeRevision(
            @Parameter(description = "Employee ID") @PathVariable Long id) {
        Revision<Long, Employee> lastRevision = employeeService.getLastEmployeeRevision(id);
        return ResponseEntity.ok(lastRevision);
    }
}
