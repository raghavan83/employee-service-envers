package com.tcs.employeeservice.employee.mapper;

import com.tcs.employeeservice.employee.dto.EmployeeDTO;
import com.tcs.employeeservice.employee.entity.Employee;
import java.util.List;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface EmployeeMapper {

    @Mapping(target = "managerId", source = "manager.id")
    @Mapping(target = "managerName", source = "manager.fullName")
    EmployeeDTO toEmployeeDTO(Employee employee);

    // @Mapping(target = "manager", ignore = true)
    // @Mapping(target = "subordinates", ignore = true)
    @Mapping(target = "createdDate", expression = "java(java.time.LocalDateTime.now().truncatedTo(java.time.temporal.ChronoUnit.MICROS))")
    // @Mapping(target = "createdBy", ignore = true)
    // @Mapping(target = "lastModifiedDate", ignore = true)
    // @Mapping(target = "lastModifiedBy", ignore = true)
    Employee toEmployee(EmployeeDTO employeeDTO);

    List<EmployeeDTO> toEmployeeDTOList(List<Employee> employees);

}
