package com.tcs.employeeservice.employee.service;



// TODO: Update the following imports to match your actual package structure.
// For example, if your DTO, entity, exception, mapper, and repository classes are under
// com.tcs.employeeservice.employee.*, update the imports accordingly:

import com.tcs.employeeservice.employee.dto.EmployeeDTO;
import com.tcs.employeeservice.employee.entity.Employee;
import com.tcs.employeeservice.employee.entity.EmployeeStatus;
import com.tcs.employeeservice.employee.exception.EmployeeNotFoundException;
import com.tcs.employeeservice.employee.exception.DuplicateEmployeeException;
import com.tcs.employeeservice.employee.mapper.EmployeeMapper;
import com.tcs.employeeservice.employee.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.history.Revision;
import org.springframework.data.history.Revisions;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class EmployeeService {
    
    private final EmployeeRepository employeeRepository;
    private final EmployeeMapper employeeMapper;
    
    @Autowired
    public EmployeeService(EmployeeRepository employeeRepository, EmployeeMapper employeeMapper) {
        this.employeeRepository = employeeRepository;
        this.employeeMapper = employeeMapper;
    }
    
    @Transactional(readOnly = true)
    public List<EmployeeDTO> getAllEmployees() {
        List<Employee> employees = employeeRepository.findAll();
        return employeeMapper.toEmployeeDTOList(employees);
    }
    
    @Transactional(readOnly = true)
    public Page<EmployeeDTO> getEmployeesWithFilters(String firstName, String lastName, 
                                                   String department, EmployeeStatus status, 
                                                   Pageable pageable) {
        Page<Employee> employees = employeeRepository.findEmployeesWithFilters(
            firstName, lastName, department, status, pageable);
        return employees.map(employeeMapper::toEmployeeDTO);
    }
    
    @Transactional(readOnly = true)
    public EmployeeDTO getEmployeeById(Long id) {
        Employee employee = employeeRepository.findById(id)
            .orElseThrow(() -> new EmployeeNotFoundException("Employee not found with id: " + id));
        return employeeMapper.toEmployeeDTO(employee);
    }
    
    @Transactional(readOnly = true)
    public EmployeeDTO getEmployeeByEmployeeNumber(String employeeNumber) {
        Employee employee = employeeRepository.findByEmployeeNumber(employeeNumber)
            .orElseThrow(() -> new EmployeeNotFoundException(
                "Employee not found with employee number: " + employeeNumber));
        return employeeMapper.toEmployeeDTO(employee);
    }
    
    public EmployeeDTO createEmployee(EmployeeDTO employeeDTO) {
        // Check for duplicates
        if (employeeRepository.existsByEmployeeNumber(employeeDTO.getEmployeeNumber())) {
            throw new DuplicateEmployeeException(
                "Employee already exists with employee number: " + employeeDTO.getEmployeeNumber());
        }
        
        if (employeeRepository.existsByEmail(employeeDTO.getEmail())) {
            throw new DuplicateEmployeeException(
                "Employee already exists with email: " + employeeDTO.getEmail());
        }
        
        Employee employee = employeeMapper.toEmployee(employeeDTO);
        
        // Set manager if managerId is provided
        if (employeeDTO.getManagerId() != null) {
            Employee manager = employeeRepository.findById(employeeDTO.getManagerId())
                .orElseThrow(() -> new EmployeeNotFoundException(
                    "Manager not found with id: " + employeeDTO.getManagerId()));
            employee.setManager(manager);
        }
        
        employee.setStatus(EmployeeStatus.ACTIVE);

        System.out.println("Employee to be saved: " + employee);
        Employee savedEmployee = employeeRepository.save(employee);
        return employeeMapper.toEmployeeDTO(savedEmployee);
    }
    
    public EmployeeDTO updateEmployee(Long id, EmployeeDTO employeeDTO) {
        Employee existingEmployee = employeeRepository.findById(id)
            .orElseThrow(() -> new EmployeeNotFoundException("Employee not found with id: " + id));
        
        // Check for email uniqueness if email is being changed
        if (!existingEmployee.getEmail().equals(employeeDTO.getEmail()) && 
            employeeRepository.existsByEmail(employeeDTO.getEmail())) {
            throw new DuplicateEmployeeException(
                "Employee already exists with email: " + employeeDTO.getEmail());
        }
        
        // Update fields
        existingEmployee.setFirstName(employeeDTO.getFirstName());
        existingEmployee.setLastName(employeeDTO.getLastName());
        existingEmployee.setEmail(employeeDTO.getEmail());
        existingEmployee.setPhoneNumber(employeeDTO.getPhoneNumber());
        existingEmployee.setJobTitle(employeeDTO.getJobTitle());
        existingEmployee.setDepartment(employeeDTO.getDepartment());
        existingEmployee.setSalary(employeeDTO.getSalary());
        
        // Update manager if managerId is provided
        if (employeeDTO.getManagerId() != null) {
            if (!employeeDTO.getManagerId().equals(
                existingEmployee.getManager() != null ? existingEmployee.getManager().getId() : null)) {
                Employee manager = employeeRepository.findById(employeeDTO.getManagerId())
                    .orElseThrow(() -> new EmployeeNotFoundException(
                        "Manager not found with id: " + employeeDTO.getManagerId()));
                existingEmployee.setManager(manager);
            }
        } else {
            existingEmployee.setManager(null);
        }
        
        Employee savedEmployee = employeeRepository.save(existingEmployee);
        return employeeMapper.toEmployeeDTO(savedEmployee);
    }
    
    public void deleteEmployee(Long id) {
        Employee employee = employeeRepository.findById(id)
            .orElseThrow(() -> new EmployeeNotFoundException("Employee not found with id: " + id));
        
        // Check if employee has subordinates
        Long subordinateCount = employeeRepository.countActiveSubordinates(id);
        if (subordinateCount > 0) {
            throw new IllegalStateException(
                "Cannot delete employee with active subordinates. Please reassign subordinates first.");
        }
        
        employeeRepository.delete(employee);
    }
    
    public EmployeeDTO terminateEmployee(Long id) {
        Employee employee = employeeRepository.findById(id)
            .orElseThrow(() -> new EmployeeNotFoundException("Employee not found with id: " + id));
        
        employee.terminate();
        Employee savedEmployee = employeeRepository.save(employee);
        return employeeMapper.toEmployeeDTO(savedEmployee);
    }
    
    public EmployeeDTO reactivateEmployee(Long id) {
        Employee employee = employeeRepository.findById(id)
            .orElseThrow(() -> new EmployeeNotFoundException("Employee not found with id: " + id));
        
        employee.reactivate();
        Employee savedEmployee = employeeRepository.save(employee);
        return employeeMapper.toEmployeeDTO(savedEmployee);
    }
    
    @Transactional(readOnly = true)
    public List<String> getAllDepartments() {
        return employeeRepository.findAllDepartments();
    }
    
    @Transactional(readOnly = true)
    public List<EmployeeDTO> getEmployeesByDepartment(String department) {
        List<Employee> employees = employeeRepository.findByDepartment(department);
        return employeeMapper.toEmployeeDTOList(employees);
    }
    
    @Transactional(readOnly = true)
    public List<EmployeeDTO> getSubordinates(Long managerId) {
        List<Employee> subordinates = employeeRepository.findByManagerId(managerId);
        return employeeMapper.toEmployeeDTOList(subordinates);
    }
    
    // Audit-related methods
    @Transactional(readOnly = true)
    public Revisions<Long, Employee> getEmployeeRevisions(Long id) {
        return employeeRepository.findRevisions(id);
    }
    
    @Transactional(readOnly = true)
    public Optional<Revision<Long, Employee>> getEmployeeRevision(Long id, Long revisionNumber) {
        return employeeRepository.findRevision(id, revisionNumber);
    }
    
    @Transactional(readOnly = true)
    public Revision<Long, Employee> getLastEmployeeRevision(Long id) {
        return employeeRepository.findLastChangeRevision(id)
            .orElseThrow(() -> new EmployeeNotFoundException(
                "No revision found for employee with id: " + id));
    }
}
